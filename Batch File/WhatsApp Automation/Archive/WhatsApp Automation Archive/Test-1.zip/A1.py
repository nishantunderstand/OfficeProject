from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# List of 10-digit numbers
raw_numbers = ["9311834004", "9711688154", "9934423413"]
message = "Hello! This is an automated message sent using Python."

# Use already logged-in Chrome profile via remote debugger
chrome_options = Options()
chrome_options.debugger_address = "127.0.0.1:9222"

# Create WebDriver using attached session
driver = webdriver.Chrome(options=chrome_options)

# Step 1: Load WhatsApp Web just once
driver.get("https://web.whatsapp.com")
WebDriverWait(driver, 30).until(
    EC.presence_of_element_located((By.XPATH, "//div[@title='Search input textbox']"))
)
print("✅ WhatsApp Web loaded.")

# Step 2: Loop and send messages
for raw_number in raw_numbers:
    phone_number = f"+91{raw_number}"
    print(f"📨 Sending to {phone_number}...")

    try:
        # Open chat using URL schema without full reload
        script = f"window.location.href = 'https://web.whatsapp.com/send?phone={phone_number}';"
        driver.execute_script(script)

        # Wait for input box to appear
        input_box = WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.XPATH, "//div[@title='Type a message']"))
        )

        time.sleep(1)  # Slight buffer
        input_box.send_keys(message + Keys.ENTER)

        print(f"✅ Message sent to {phone_number}")
        time.sleep(5)  # Delay before next message

    except Exception as e:
        print(f"❌ Failed to send to {phone_number}: {e}")
        time.sleep(3)

print("✅ All messages sent successfully.")