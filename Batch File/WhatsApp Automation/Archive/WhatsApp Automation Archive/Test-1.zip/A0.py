from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import traceback

# 🟢 List of target numbers
raw_numbers = ["9311834004", "9711688154", "9934423413"]
message = "Hello! This is an automated message sent using Python."

# 🧠 Reuse Chrome session
chrome_options = Options()
chrome_options.debugger_address = "127.0.0.1:9222"
driver = webdriver.Chrome(options=chrome_options)

for raw_number in raw_numbers:
    phone_number = f"+91{raw_number}"
    print(f"📨 Sending to {phone_number}...")

    try:
        # Open chat with pre-filled message
        driver.get(f"https://web.whatsapp.com/send?phone={phone_number}&text={message}")
        time.sleep(5)

        # Click "Continue to Chat" if needed
        try:
            continue_button = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.XPATH, "//a[contains(@href, 'web.whatsapp.com/send')]"))
            )
            continue_button.click()
            print("🔄 Clicked 'Continue to Chat'")
            time.sleep(3)
        except:
            pass  # Not always needed

        # Wait for input box to appear
        input_box = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, "//div[@title='Type a message']"))
        )
        time.sleep(1)

        # Use JS to click the Send button
        send_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//span[@data-icon='send']"))
        )
        send_button.click()

        print(f"✅ Message sent to {phone_number}")
        time.sleep(4)

    except Exception:
        print(f"❌ Failed to send to {phone_number}")
        traceback.print_exc()

print("🏁 All messages processed.")
