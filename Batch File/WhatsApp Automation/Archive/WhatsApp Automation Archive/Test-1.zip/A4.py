import pywhatkit as kit
import time

# All numbers are assumed to be Indian 10-digit numbers
raw_numbers = ["9311834004", "9711688154", "9934423413"]

# Message to send
message = "Hello! This is an automated message sent instantly using Python."

for i, raw_number in enumerate(raw_numbers):
    phone_number = f"+91{raw_number}"
    print(f"Sending to {phone_number}...")
    
    # Close tab only after sending to last number
    is_last = (i == len(raw_numbers) - 1)

    kit.sendwhatmsg_instantly(
        phone_no=phone_number,
        message=message,
        wait_time=15,
        tab_close=is_last
    )
    
    time.sleep(10)  # Short delay to avoid overlap

print("✅ All messages sent successfully.")
