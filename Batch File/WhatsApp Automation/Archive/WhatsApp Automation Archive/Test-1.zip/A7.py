from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# === SETTINGS ===
raw_numbers = ["9311834004", "9711688154", "9934423413"]  # Add numbers with country code but without '+' or '00'
country_code = "91"  # Change according to your country
messages = [
    "Hello from Python automation!",
    "This is an automated test message."
]
delay_between_messages = 5  # seconds
delay_between_contacts = 10  # seconds

# === CHROME OPTIONS TO CONNECT TO DEBUGGING PORT ===
chrome_options = Options()
chrome_options.debugger_address = "127.0.0.1:9222"  # Connect to the already running Chrome

# Launch driver using existing Chrome session
driver = webdriver.Chrome(service=Service(), options=chrome_options)

def send_whatsapp_message(number, messages):
    try:
        print(f"🔃 Opening chat with {number}...")
        driver.get(f"https://web.whatsapp.com/send?phone={country_code}{number}")
        
        # Wait for the chat to load
        WebDriverWait(driver, 60).until(
            EC.presence_of_element_located((By.XPATH, "//div[@title='Type a message']"))
        )
        print(f"✅ Chat with {number} is loaded.")
        
        # Send multiple messages
        for message in messages:
            input_box = driver.find_element(By.XPATH, "//div[@title='Type a message']")
            input_box.send_keys(message)
            input_box.send_keys(u'\ue007')  # Press Enter
            print(f"✅ Sent to {number}: {message}")
            time.sleep(delay_between_messages)
            
        return True
        
    except Exception as e:
        print(f"❌ Error sending to {number}: {e}")
        return False

try:
    # First load WhatsApp Web homepage to establish connection
    print("🔃 Loading WhatsApp Web...")
    driver.get("https://web.whatsapp.com")
    time.sleep(5)  # Wait for initial load

    # Process each number
    for number in raw_numbers:
        success = send_whatsapp_message(number, messages)
        time.sleep(delay_between_contacts)

except Exception as e:
    print(f"❌ Critical error: {e}")

finally:
    time.sleep(5)
    # driver.quit()  # Optional: don't close browser if reusings
    