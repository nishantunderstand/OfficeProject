from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# Raw 10-digit mobile numbers (Indian numbers assumed)
raw_numbers = ["9311834004", "9711688154", "9934423413"]
message = "Hello! This is an automated message sent via Selenium."

# Initialize browser and login to WhatsApp Web
driver = webdriver.Chrome()
driver.get("https://web.whatsapp.com")
time.sleep(10)  # Wait for WhatsApp Web to fully load

for number in raw_numbers:
    phone_number = f"+91{number}"  # Add country code
    print(f"Sending to: {phone_number}")

    # Open chat with the number using wa.me
    driver.get(f"https://wa.me/{phone_number.replace('+', '')}")
    time.sleep(5)

    # Click on "Continue to Chat" button
    try:
        driver.find_element(By.XPATH, "//a[text()='Continue to Chat']").click()
        time.sleep(3)
    except:
        print(f"❌ Could not open chat with {phone_number}")
        continue

    # Wait for WhatsApp chat window to load
    try:
        driver.find_element(By.XPATH, "//a[contains(@href,'web.whatsapp.com/send')]").click()
        time.sleep(6)

        # Send the message
        message_box = driver.find_element(By.XPATH, '//div[@contenteditable="true"][@data-tab="10"]')
        message_box.send_keys(message)
        message_box.send_keys(Keys.ENTER)
        time.sleep(2)

        print(f"✅ Message sent to {phone_number}")
    except Exception as e:
        print(f"⚠️ Failed to send message to {phone_number}: {e}")

print("✅ All messages processed.")