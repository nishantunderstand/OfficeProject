import pyautogui
import pyperclip
import pygetwindow as gw
import time

# List of 10-digit Indian numbers (must be saved in your contacts)
raw_numbers = ["9311834004", "9711688154", "9934423413"]
message = "Hello! This is an automated message sent via WhatsApp Desktop."

# Add country code
contacts = [f"+91{num}" for num in raw_numbers]

# Focus WhatsApp Desktop
try:
    wa_window = gw.getWindowsWithTitle("WhatsApp")[0]
    wa_window.restore()
    wa_window.activate()
    time.sleep(2)
except IndexError:
    print("❌ WhatsApp Desktop window not found!")
    exit()

# Ask user to place mouse over search bar
print("📍 Move your mouse over the WhatsApp Search Box in 5 seconds...")
time.sleep(5)
search_coords = pyautogui.position()
print(f"✅ Captured Search Box Position: {search_coords}")

# Ask user to place mouse over message box
print("📍 Now move your mouse over the Message Box (chat input) in 5 seconds...")
time.sleep(5)
msg_coords = pyautogui.position()
print(f"✅ Captured Message Box Position: {msg_coords}")

# Now loop through contacts
for contact in contacts:
    print(f"🔍 Searching and messaging: {contact}")

    # Click on search box
    pyautogui.click(search_coords)
    time.sleep(1)
    pyperclip.copy(contact)
    pyautogui.hotkey("ctrl", "v")
    time.sleep(1)
    pyautogui.press("enter")
    time.sleep(2)

    # Click on message box
    pyautogui.click(msg_coords)
    time.sleep(1)
    pyperclip.copy(message)
    pyautogui.hotkey("ctrl", "v")
    time.sleep(1)
    pyautogui.press("enter")
    time.sleep(1)

print("✅ All messages sent successfully!")
