from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# ✅ Message and phone list
raw_numbers = ["9311834004", "9711688154", "9934423413"]
message = "Hello! This is an automated message sent instantly using Python."

# ✅ Setup Chrome debugging connection
chrome_options = Options()
chrome_options.debugger_address = "127.0.0.1:9222"  # Reuse already-open Chrome with WhatsApp

driver = webdriver.Chrome(service=Service(), options=chrome_options)
driver.get("https://web.whatsapp.com")
WebDriverWait(driver, 60).until(EC.presence_of_element_located((By.XPATH, "//div[@title='Search input textbox']")))

# ✅ Loop through contacts
for number in raw_numbers:
    phone_number = f"+91{number}"
    print(f"Sending to {phone_number}...")

    # Open chat using WhatsApp URL scheme
    driver.get(f"https://web.whatsapp.com/send?phone={phone_number}&text={message}")
    
    try:
        # Wait for the message box to load and press Enter to send
        message_box = WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//div[@title='Type a message']"))
        )
        message_box.send_keys(u'\ue007')  # Press Enter

        print(f"✅ Message sent to {phone_number}")
        time.sleep(5)  # Delay before next message

    except Exception as e:
        print(f"❌ Failed to send to {phone_number}: {e}")

print("✅ All messages sent successfully.")