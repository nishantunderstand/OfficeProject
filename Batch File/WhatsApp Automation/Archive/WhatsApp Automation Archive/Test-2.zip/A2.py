import pywhatkit as kit

# Just use the 10-digit number (without +91)
raw_number = "9311834004"
message = "Hello! This is an automated message sent instantly using Python."

# Automatically add +91
phone_number = f"+91{raw_number}"

# Send message instantly
kit.sendwhatmsg_instantly(phone_number, message, wait_time=15, tab_close=True)

print("Message sent instantly.")

