// ==UserScript==
// @name         Notion AutoScroll Button 2 Interruption Renew
// @namespace    http://tampermonkey.net/
// @version      1.3
// @description  Auto-scrolls Notion page, resumes after interaction
// @match        https://www.notion.so/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const waitForScrollContainer = () => {
        return new Promise((resolve) => {
            const interval = setInterval(() => {
                const container = document.querySelector('[data-root-scroller]') ||
                                  document.querySelector('[role="main"] div[style*="overflow"]') ||
                                  document.querySelector('.notion-scroller');
                if (container) {
                    clearInterval(interval);
                    resolve(container);
                }
            }, 500);
        });
    };

    const createScrollButton = (scrollContainer) => {
        const btn = document.createElement('button');
        btn.textContent = '▶️ AutoScroll';
        Object.assign(btn.style, {
            position: 'fixed',
            bottom: '20px',
            right: '20px',
            padding: '10px 15px',
            fontSize: '14px',
            backgroundColor: '#333',
            color: '#fff',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            zIndex: '99999'
        });

        document.body.appendChild(btn);

        let intervalId = null;
        let userInterrupted = false;
        let resumeTimeoutId = null;

        const startScroll = () => {
            if (intervalId) return;
            btn.textContent = '⏹ Stop';
            intervalId = setInterval(() => {
                scrollContainer.scrollBy(0, 0.4);
                if (scrollContainer.scrollTop + scrollContainer.clientHeight >= scrollContainer.scrollHeight) {
                    stopScroll();
                }
            }, 20);
        };

        const stopScroll = () => {
            if (intervalId) clearInterval(intervalId);
            intervalId = null;
            btn.textContent = '▶️ AutoScroll';
        };

        const pauseAndScheduleResume = () => {
            stopScroll();
            userInterrupted = true;
            if (resumeTimeoutId) clearTimeout(resumeTimeoutId);
            resumeTimeoutId = setTimeout(() => {
                userInterrupted = false;
                startScroll();
            }, 5000);
        };

        // Manual toggle by button
        btn.onclick = () => {
            if (intervalId) {
                stopScroll();
            } else {
                startScroll();
            }
        };

        // Pause on interaction
        ['mousedown', 'keydown', 'wheel', 'touchstart'].forEach(event => {
            document.addEventListener(event, pauseAndScheduleResume, { passive: true });
        });

        // Auto-start after 5 seconds
        setTimeout(() => {
            if (!intervalId && !userInterrupted) {
                startScroll();
            }
        }, 5000);
    };

    window.addEventListener('load', async () => {
        const container = await waitForScrollContainer();
        if (container) createScrollButton(container);
    });
})();
