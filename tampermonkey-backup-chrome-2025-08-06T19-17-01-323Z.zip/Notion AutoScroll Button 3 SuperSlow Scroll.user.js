// ==UserScript==
// @name         Notion AutoScroll Button 3 SuperSlow Scroll
// @namespace    http://tampermonkey.net/
// @version      1.4
// @description  Auto-scrolls Notion page, resumes after interaction (smooth fractional scroll)
// @match        https://www.notion.so/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const waitForScrollContainer = () => {
        return new Promise((resolve) => {
            const interval = setInterval(() => {
                const container = document.querySelector('[data-root-scroller]') ||
                                  document.querySelector('[role="main"] div[style*="overflow"]') ||
                                  document.querySelector('.notion-scroller');
                if (container) {
                    clearInterval(interval);
                    resolve(container);
                }
            }, 500);
        });
    };

    const createScrollButton = (scrollContainer) => {
        const btn = document.createElement('button');
        btn.textContent = '▶️ AutoScroll';
        Object.assign(btn.style, {
            position: 'fixed',
            bottom: '20px',
            right: '20px',
            padding: '10px 15px',
            fontSize: '14px',
            backgroundColor: '#333',
            color: '#fff',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            zIndex: '99999'
        });

        document.body.appendChild(btn);

        let isScrolling = false;
        let interrupted = false;
        let resumeTimeout = null;

        let fractionalScroll = 0;
        const scrollSpeed = 0.3; // fractional pixels per frame

        const scrollStep = () => {
            if (!isScrolling) return;

            fractionalScroll += scrollSpeed;
            const scrollAmount = Math.floor(fractionalScroll);
            if (scrollAmount >= 1) {
                scrollContainer.scrollBy(0, scrollAmount);
                fractionalScroll -= scrollAmount;
            }

            // Stop if end of page reached
            if (scrollContainer.scrollTop + scrollContainer.clientHeight >= scrollContainer.scrollHeight) {
                stopScroll();
                return;
            }

            requestAnimationFrame(scrollStep);
        };

        const startScroll = () => {
            if (isScrolling) return;
            isScrolling = true;
            btn.textContent = '⏹ Stop';
            requestAnimationFrame(scrollStep);
        };

        const stopScroll = () => {
            isScrolling = false;
            btn.textContent = '▶️ AutoScroll';
        };

        const pauseAndScheduleResume = () => {
            stopScroll();
            interrupted = true;
            if (resumeTimeout) clearTimeout(resumeTimeout);
            resumeTimeout = setTimeout(() => {
                interrupted = false;
                startScroll();
            }, 5000); // 5 seconds resume
        };

        // Manual toggle by button
        btn.onclick = () => {
            if (isScrolling) {
                stopScroll();
            } else {
                startScroll();
            }
        };

        // Pause on user interaction
        ['mousedown', 'keydown', 'wheel', 'touchstart'].forEach(event => {
            document.addEventListener(event, pauseAndScheduleResume, { passive: true });
        });

        // Auto-start after 5 seconds
        setTimeout(() => {
            if (!isScrolling && !interrupted) {
                startScroll();
            }
        }, 5000);
    };

    window.addEventListener('load', async () => {
        const container = await waitForScrollContainer();
        if (container) createScrollButton(container);
    });
})();
