// ==UserScript==
// @name         Quick Navigation Bar 2 (Gmail-Compatible + ChatGPT)
// @namespace    http://tampermonkey.net/
// @version      2.6
// @description  Minimal floating nav bar with fullscreen + quick access links (auto-hide, ChatGPT added)
// @match        *://*/*
// @grant        GM_openInTab
// ==/UserScript==

(function () {
  'use strict';

  // Avoid iframes like Gmail's inner frame
  if (window.top !== window.self) return;

  const sites = [
    { name: 'Scaler', url: 'https://www.scaler.com/academy/mentee-dashboard/core-curriculum/m/84/classes' },
    { name: 'Notion', url: 'https://www.notion.so/' },
    { name: 'Todoist', url: 'https://app.todoist.com/app/inbox/' },
    { name: 'Calender', url: 'https://calendar.google.com/calendar/u/0/r' },
    { name: 'Simplenote', url: 'https://app.simplenote.com/' },
    { name: 'WhatsApp', url: 'https://web.whatsapp.com/' },
    { name: 'XMind', url: 'https://xmind.ai/home/recents' },
    { name: 'ChatGPT', url: 'https://chatgpt.com/' }  
  ];

  document.getElementById('tm-nav-bar')?.remove();
  document.getElementById('tm-nav-toggle')?.remove();

  const bar = document.createElement('div');
  bar.id = 'tm-nav-bar';
  Object.assign(bar.style, {
    position: 'fixed',
    top: '50px',
    right: '10px',
    display: 'flex',
    flexDirection: 'column',
    gap: '12px',
    zIndex: '2147483647'
  });

  function createButton(label, action) {
    const btn = document.createElement('div');
    btn.textContent = label;
    Object.assign(btn.style, {
      cursor: 'pointer',
      background: '#e3e8ee',
      color: '#3b4252',
      fontWeight: '500',
      fontSize: '13px',
      padding: '4px 10px',
      borderRadius: '7px',
      border: '1px solid #cbd5e1',
      boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
      transition: 'background 0.2s, color 0.2s',
    });
    btn.onmouseover = () => {
      btn.style.background = '#c7d2fe';
      btn.style.color = '#1e293b';
    };
    btn.onmouseout = () => {
      btn.style.background = '#e3e8ee';
      btn.style.color = '#3b4252';
    };
    btn.onclick = action;
    return btn;
  }

  sites.forEach(site => {
    const btn = createButton(site.name, () => window.open(site.url, '_blank'));
    bar.appendChild(btn);
  });

  const fullScreenBtn = createButton('Toggle Fullscreen', () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(console.error);
    } else {
      document.exitFullscreen();
    }
  });
  bar.appendChild(fullScreenBtn);

  document.body.appendChild(bar);

  const toggleBtn = document.createElement('div');
  toggleBtn.id = 'tm-nav-toggle';
  Object.assign(toggleBtn.style, {
    position: 'fixed',
    top: '50px',
    right: '10px',
    width: '36px',
    height: '36px',
    background: '#22c55e',
    borderRadius: '50%',
    boxShadow: '0 1px 6px rgba(0,0,0,0.10)',
    display: 'none',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: '2147483647',
    cursor: 'pointer'
  });
  toggleBtn.title = 'Show Navigation';
  toggleBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 18 18" fill="none"><circle cx="9" cy="9" r="9" fill="#22c55e"/><path d="M9 5v8M5 9h8" stroke="#fff" stroke-width="2" stroke-linecap="round"/></svg>';

  toggleBtn.onclick = () => {
    const visible = bar.style.display !== 'none';
    bar.style.display = visible ? 'none' : 'flex';
    toggleBtn.style.display = visible ? 'flex' : 'none';
  };

  document.body.appendChild(toggleBtn);

  setTimeout(() => {
    bar.style.display = 'none';
    toggleBtn.style.display = 'flex';
  }, 3000);
})();
