// ==UserScript==
// @name         Notion AutoScroll Button 1
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Adds a working auto-scroll button for Notion's scroll container
// @match        https://www.notion.so/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const waitForScrollContainer = () => {
        return new Promise((resolve) => {
            const interval = setInterval(() => {
                const container = document.querySelector('[data-root-scroller]') ||
                                  document.querySelector('[role="main"] div[style*="overflow"]') ||
                                  document.querySelector('.notion-scroller');
                if (container) {
                    clearInterval(interval);
                    resolve(container);
                }
            }, 500);
        });
    };

    const createScrollButton = (scrollContainer) => {
        const btn = document.createElement('button');
        btn.textContent = '▶️ AutoScroll';
        Object.assign(btn.style, {
            position: 'fixed',
            bottom: '20px',
            right: '20px',
            padding: '10px 15px',
            fontSize: '14px',
            backgroundColor: '#333',
            color: '#fff',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            zIndex: '99999'
        });

        document.body.appendChild(btn);

        let intervalId = null;

        btn.onclick = () => {
            if (intervalId) {
                clearInterval(intervalId);
                intervalId = null;
                btn.textContent = '▶️ AutoScroll';
            } else {
                btn.textContent = '⏹ Stop';
                intervalId = setInterval(() => {
                    scrollContainer.scrollBy(0, 0.5); // speed control
                    if (scrollContainer.scrollTop + scrollContainer.clientHeight >= scrollContainer.scrollHeight) {
                        clearInterval(intervalId);
                        intervalId = null;
                        btn.textContent = '▶️ AutoScroll';
                    }
                }, 20);
            }
        };
    };

    // Initialize after DOM is ready
    window.addEventListener('load', async () => {
        const container = await waitForScrollContainer();
        if (container) createScrollButton(container);
    });
})();
