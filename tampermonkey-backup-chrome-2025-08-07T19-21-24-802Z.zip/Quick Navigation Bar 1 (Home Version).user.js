// ==UserScript==
// @name         Quick Navigation Bar 1 (Home Version)
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Adds a small, eye-pleasing navigation bar for quick access to frequently used sites on all websites.
// @author       Copilot
// @match        *://*/*
// @grant        GM_openInTab
// ==/UserScript==

(function () {
  'use strict';

  // --- Navigation Bar ---
  const sites = [
    { name: 'Scaler', url: 'https://www.scaler.com/academy/mentee-dashboard/core-curriculum/m/84/classes' },
    { name: 'Notion', url: 'https://www.notion.so/' },
    { name: 'XMind', url: 'https://xmind.ai/home/recents' },
    { name: 'WhatsApp', url: 'https://web.whatsapp.com/' },
    { name: 'Simplenote', url: 'https://app.simplenote.com/' }
  ];

  let lastUrl = localStorage.getItem('lastNavUrl') || '';
  let currentUrl = window.location.href;

  function saveCurrentUrl() {
    localStorage.setItem('lastNavUrl', window.location.href);
  }

  // Remove existing elements if already present
  let oldBar = document.getElementById('tm-nav-bar');
  if (oldBar) oldBar.remove();
  let oldBtn = document.getElementById('tm-nav-toggle');
  if (oldBtn) oldBtn.remove();

  // --- Create Navigation Bar ---
  let bar = document.createElement('div');
  bar.id = 'tm-nav-bar';
  bar.style.position = 'fixed';
  bar.style.top = '50px';
  bar.style.right = '10px';
  bar.style.display = 'flex';
  bar.style.flexDirection = 'column';
  bar.style.gap = '12px';
  bar.style.zIndex = '99999';

  // Create site buttons
  sites.forEach(site => {
    let label = document.createElement('div');
    label.textContent = site.name;
    label.title = site.name;
    label.style.cursor = 'pointer';
    label.style.background = '#e3e8ee';
    label.style.color = '#3b4252';
    label.style.fontWeight = '500';
    label.style.fontSize = '13px';
    label.style.padding = '4px 10px';
    label.style.margin = '1px 0';
    label.style.borderRadius = '7px';
    label.style.border = '1px solid #cbd5e1';
    label.style.boxShadow = '0 1px 4px rgba(0,0,0,0.04)';
    label.style.transition = 'background 0.2s, color 0.2s';
    label.onmouseover = function () {
      label.style.background = '#c7d2fe';
      label.style.color = '#1e293b';
    };
    label.onmouseout = function () {
      label.style.background = '#e3e8ee';
      label.style.color = '#3b4252';
    };
    label.onclick = function () {
      saveCurrentUrl();
      window.open(site.url, '_blank');
    };
    bar.appendChild(label);
  });

  document.body.appendChild(bar);

  // --- Toggle Button ---
  let toggleBtn = document.createElement('div');
  toggleBtn.id = 'tm-nav-toggle';
  toggleBtn.style.position = 'fixed';
  toggleBtn.style.top = '50px';
  toggleBtn.style.right = '10px';
  toggleBtn.style.width = '36px';
  toggleBtn.style.height = '36px';
  toggleBtn.style.background = '#22c55e';
  toggleBtn.style.borderRadius = '50%';
  toggleBtn.style.boxShadow = '0 1px 6px rgba(0,0,0,0.10)';
  toggleBtn.style.display = 'none';
  toggleBtn.style.justifyContent = 'center';
  toggleBtn.style.alignItems = 'center';
  toggleBtn.style.zIndex = '99999';
  toggleBtn.style.cursor = 'pointer';
  toggleBtn.title = 'Show Navigation';
  toggleBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="9" cy="9" r="9" fill="#22c55e"/><path d="M9 5v8M5 9h8" stroke="#fff" stroke-width="2" stroke-linecap="round"/></svg>';

  document.body.appendChild(toggleBtn);

  // Auto-hide nav bar after a few seconds, show toggle button
  setTimeout(() => {
    bar.style.display = 'none';
    toggleBtn.style.display = 'flex';
  }, 3000);

  // Toggle logic
  toggleBtn.onclick = function () {
    if (bar.style.display === 'none') {
      bar.style.display = 'flex';
      toggleBtn.style.display = 'none';
    } else {
      bar.style.display = 'none';
      toggleBtn.style.display = 'flex';
    }
  };
})();
