// ==UserScript==
// @name         Instagram Auto-Unmute 1
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Auto-unmute Instagram videos on Feed and Reels
// @match        https://www.instagram.com/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const unmute = () => {
        document.querySelectorAll('video').forEach(video => {
            if (video.muted) {
                video.muted = false;
                video.volume = 1.0;
                // force play if paused
                if (video.paused) video.play().catch(() => {});
            }
        });
    };

    // Observe DOM for new videos (for Reels, feed scroll, etc.)
    const observer = new MutationObserver(() => {
        unmute();
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    // Run on interval in case MutationObserver misses something
    setInterval(unmute, 1000);
})();
