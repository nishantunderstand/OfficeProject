// ==UserScript==
// @name         Quick Navigation Bar 4
// @namespace    http://tampermonkey.net/
// @version      3.2
// @description  Pomodoro + quick links all in one row, fullscreen on button click
// @match        *://*/*
// @grant        GM_openInTab
// ==/UserScript==

(function () {
  'use strict';

  if (window.top !== window.self) return;

  const sites = [
    { name: 'Scaler', url: 'https://www.scaler.com/academy/mentee-dashboard/core-curriculum/m/84/classes' },
    { name: 'Notion', url: 'https://www.notion.so/' },
    { name: 'Todoist', url: 'https://app.todoist.com/app/inbox/' },
    { name: 'Calender', url: 'https://calendar.google.com/calendar/u/0/r' },
    { name: 'Simplenote', url: 'https://app.simplenote.com/' },
    { name: 'WhatsApp', url: 'https://web.whatsapp.com/' },
    { name: 'XMind', url: 'https://xmind.ai/home/recents' },
    { name: 'ChatGPT', url: 'https://chatgpt.com/' }
  ];

  document.getElementById('tm-nav-bar')?.remove();

  const navBar = document.createElement('div');
  navBar.id = 'tm-nav-bar';
  Object.assign(navBar.style, {
    position: 'fixed',
    top: '0',
    left: '0',
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    flexWrap: 'wrap',
    padding: '6px 12px',
    background: '#f8fafc',
    boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
    zIndex: '2147483647',
    gap: '10px',
    justifyContent: 'center'
  });

  function createButton(label, onClickAction) {
    const btn = document.createElement('div');
    btn.textContent = label;
    Object.assign(btn.style, {
      cursor: 'pointer',
      background: '#e3e8ee',
      color: '#1e293b',
      fontWeight: '500',
      fontSize: '13px',
      padding: '4px 10px',
      borderRadius: '7px',
      border: '1px solid #cbd5e1',
      boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
      whiteSpace: 'nowrap',
      transition: 'background 0.2s, color 0.2s',
      display: 'flex',
      alignItems: 'center',
      gap: '5px'
    });

    btn.onmouseover = () => {
      btn.style.background = '#c7d2fe';
    };
    btn.onmouseout = () => {
      btn.style.background = '#e3e8ee';
    };

    btn.onclick = async () => {
      try {
        if (!document.fullscreenElement) {
          await document.documentElement.requestFullscreen();
        }
      } catch (e) {
        console.error('Fullscreen request failed:', e);
      }
      onClickAction();
    };

    return btn;
  }

  // Pomodoro Timer
  const timerDisplay = document.createElement('span');
  timerDisplay.textContent = '';
  Object.assign(timerDisplay.style, {
    fontWeight: 'bold',
    color: '#ef4444',
    padding: '4px 8px',
    fontSize: '13px',
    whiteSpace: 'nowrap'
  });

  const pomodoroBtn = createButton('⏵ Start 30 Min', () => {
    let duration = 30 * 60;
    pomodoroBtn.style.opacity = 0.5;
    pomodoroBtn.style.pointerEvents = 'none';
    const timer = setInterval(() => {
      const mins = Math.floor(duration / 60);
      const secs = duration % 60;
      timerDisplay.textContent = `⏳ ${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
      duration--;
      if (duration < 0) {
        clearInterval(timer);
        timerDisplay.textContent = '✅ Done!';
        pomodoroBtn.style.opacity = 1;
        pomodoroBtn.style.pointerEvents = 'auto';
      }
    }, 1000);
  });

  navBar.appendChild(pomodoroBtn);
  navBar.appendChild(timerDisplay);

  // Quick Link Buttons
  sites.forEach(site => {
    const btn = createButton(site.name, () => {
      window.open(site.url, '_blank');
    });
    navBar.appendChild(btn);
  });

  // Optional: Manual fullscreen toggle button
  const fullScreenBtn = createButton('Fullscreen', () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else {
      document.exitFullscreen();
    }
  });
  navBar.appendChild(fullScreenBtn);

  document.body.appendChild(navBar);
})();
