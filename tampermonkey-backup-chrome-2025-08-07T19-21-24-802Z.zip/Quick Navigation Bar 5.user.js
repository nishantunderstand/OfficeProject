// ==UserScript==
// @name         Quick Navigation Bar 5
// @namespace    http://tampermonkey.net/
// @version      3.5
// @description  Transparent nav bar with persistent fullscreen Pomodoro timer
// @match        *://*/*
// @grant        GM_openInTab
// ==/UserScript==

(function () {
  'use strict';

  if (window.top !== window.self) return;

  const sites = [
    { name: 'Scaler', url: 'https://www.scaler.com/academy/mentee-dashboard/core-curriculum/m/84/classes' },
    { name: 'Notion', url: 'https://www.notion.so/' },
    { name: 'Todoist', url: 'https://app.todoist.com/app/inbox/' },
    { name: 'Calender', url: 'https://calendar.google.com/calendar/u/0/r' },
    { name: 'Simplenote', url: 'https://app.simplenote.com/' },
    { name: 'WhatsApp', url: 'https://web.whatsapp.com/' },
    { name: 'XMind', url: 'https://xmind.ai/home/recents' },
    { name: 'ChatGPT', url: 'https://chatgpt.com/' }
  ];

  document.getElementById('tm-nav-bar')?.remove();

  const navBar = document.createElement('div');
  navBar.id = 'tm-nav-bar';
  Object.assign(navBar.style, {
    position: 'fixed',
    top: '0',
    left: '0',
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    flexWrap: 'wrap',
    padding: '6px 12px',
    background: 'transparent', // ✅ Fully transparent background
    backdropFilter: 'none',    // ✅ No blur at all
    boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
    zIndex: '2147483647',
    gap: '10px',
    justifyContent: 'center'
  });

  function createButton(label, onClickAction, triggerFullscreen = false) {
    const btn = document.createElement('div');
    btn.textContent = label;
    Object.assign(btn.style, {
      cursor: 'pointer',
      background: 'rgba(255, 255, 255, 0.6)',
      color: '#1e293b',
      fontWeight: '500',
      fontSize: '13px',
      padding: '4px 10px',
      borderRadius: '7px',
      border: '1px solid #cbd5e1',
      boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
      whiteSpace: 'nowrap',
      transition: 'background 0.2s, color 0.2s',
      display: 'flex',
      alignItems: 'center',
      gap: '5px',
      backdropFilter: 'blur(3px)'
    });

    btn.onmouseover = () => {
      btn.style.background = 'rgba(199, 210, 254, 0.8)';
    };
    btn.onmouseout = () => {
      btn.style.background = 'rgba(255, 255, 255, 0.6)';
    };

    btn.onclick = async () => {
      try {
        if (triggerFullscreen && !document.fullscreenElement) {
          await document.documentElement.requestFullscreen();
        }
      } catch (e) {
        console.error('Fullscreen request failed:', e);
      }
      onClickAction();
    };

    return btn;
  }

  const timerDisplay = document.createElement('span');
  Object.assign(timerDisplay.style, {
    fontWeight: 'bold',
    color: '#ef4444',
    padding: '4px 8px',
    fontSize: '13px',
    whiteSpace: 'nowrap'
  });

  const pomodoroBtn = createButton('⏵ Start 30 Min', () => {
    const endTime = Date.now() + 30 * 60 * 1000;
    localStorage.setItem('pomodoroEndTime', endTime.toString());
    updatePomodoroState();
    broadcastPomodoroState(endTime);
  }, true);

  function updatePomodoroState() {
    const endTime = parseInt(localStorage.getItem('pomodoroEndTime'), 10);
    const now = Date.now();
    if (endTime && now < endTime) {
      pomodoroBtn.style.opacity = 0.5;
      pomodoroBtn.style.pointerEvents = 'none';
      timerDisplay.textContent = '⏳ Focus Mode';
      setTimeout(updatePomodoroState, 1000);
    } else if (endTime && now >= endTime) {
      localStorage.removeItem('pomodoroEndTime');
      pomodoroBtn.style.opacity = 1;
      pomodoroBtn.style.pointerEvents = 'auto';
      timerDisplay.textContent = '✅ Done!';
    } else {
      pomodoroBtn.style.opacity = 1;
      pomodoroBtn.style.pointerEvents = 'auto';
      timerDisplay.textContent = '';
    }
  }

  function broadcastPomodoroState(endTime) {
    localStorage.setItem('pomodoroBroadcast', JSON.stringify({
      endTime,
      timestamp: Date.now()
    }));
  }

  window.addEventListener('storage', (event) => {
    if (event.key === 'pomodoroBroadcast') {
      const data = JSON.parse(event.newValue || '{}');
      if (data.endTime) {
        localStorage.setItem('pomodoroEndTime', data.endTime.toString());
        updatePomodoroState();
      }
    }
  });

  navBar.appendChild(pomodoroBtn);
  navBar.appendChild(timerDisplay);

  updatePomodoroState();

  sites.forEach(site => {
    const btn = createButton(site.name, () => {
      window.open(site.url, '_blank');
    });
    navBar.appendChild(btn);
  });

  const fullScreenBtn = createButton('Fullscreen', () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else {
      document.exitFullscreen();
    }
  });

  navBar.appendChild(fullScreenBtn);

  document.body.appendChild(navBar);
})();
