// ==UserScript==
// @name         Universal AutoScroll Button 2 Interruption Renew
// @namespace    http://tampermonkey.net/
// @version      2.0
// @description  Auto-scrolls any webpage, resumes after interaction
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const waitForScrollContainer = () => {
        return new Promise((resolve) => {
            const interval = setInterval(() => {
                // Try to find the main scrollable container
                const container = document.scrollingElement || // Modern browsers
                                  document.documentElement ||   // Fallback
                                  document.body ||              // Older browsers
                                  document.querySelector('[data-root-scroller]') ||
                                  document.querySelector('[role="main"]') ||
                                  document.querySelector('main') ||
                                  document.querySelector('#main') ||
                                  document.querySelector('.main-content') ||
                                  document.querySelector('[style*="overflow"]');
                if (container) {
                    clearInterval(interval);
                    resolve(container);
                }
            }, 500);
        });
    };

    const createScrollButton = (scrollContainer) => {
        const btn = document.createElement('button');
        btn.textContent = '▶️ AutoScroll';
        Object.assign(btn.style, {
            position: 'fixed',
            bottom: '20px',
            right: '20px',
            padding: '10px 15px',
            fontSize: '14px',
            backgroundColor: '#333',
            color: '#fff',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            zIndex: '99999'
        });

        document.body.appendChild(btn);

        let intervalId = null;
        let userInterrupted = false;
        let resumeTimeoutId = null;

        const startScroll = () => {
            if (intervalId) return;
            btn.textContent = '⏹ Stop';
            intervalId = setInterval(() => {
                // Use window.scrollBy for document scrolling or element scrollBy for specific containers
                if (scrollContainer === document.scrollingElement ||
                    scrollContainer === document.documentElement ||
                    scrollContainer === document.body) {
                    window.scrollBy(0, 0.5);
                    // Check if we've reached the bottom of the page
                    if (window.innerHeight + window.pageYOffset >= document.body.offsetHeight) {
                        stopScroll();
                    }
                } else {
                    scrollContainer.scrollBy(0, 0.5);
                    if (scrollContainer.scrollTop + scrollContainer.clientHeight >= scrollContainer.scrollHeight) {
                        stopScroll();
                    }
                }
            }, 20);
        };

        const stopScroll = () => {
            if (intervalId) clearInterval(intervalId);
            intervalId = null;
            btn.textContent = '▶️ AutoScroll';
        };

        const pauseAndScheduleResume = () => {
            stopScroll();
            userInterrupted = true;
            if (resumeTimeoutId) clearTimeout(resumeTimeoutId);
            resumeTimeoutId = setTimeout(() => {
                userInterrupted = false;
                startScroll();
            }, 5000);
        };

        // Manual toggle by button
        btn.onclick = () => {
            if (intervalId) {
                stopScroll();
            } else {
                startScroll();
            }
        };

        // Pause on interaction
        ['mousedown', 'keydown', 'wheel', 'touchstart'].forEach(event => {
            document.addEventListener(event, pauseAndScheduleResume, { passive: true });
        });

        // Auto-start after 5 seconds
        setTimeout(() => {
            if (!intervalId && !userInterrupted) {
                startScroll();
            }
        }, 5000);
    };

    window.addEventListener('load', async () => {
        const container = await waitForScrollContainer();
        if (container) createScrollButton(container);
    });
})();
